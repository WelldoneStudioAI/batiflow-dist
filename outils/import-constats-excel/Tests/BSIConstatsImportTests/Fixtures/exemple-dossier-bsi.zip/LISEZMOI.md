# Dossier BSI — exemple-rapport-bsi

Produit le 2026-09-18 09 h 39 min 06 s à partir de `exemple-rapport-bsi.xlsx`
(feuille « Extérieur ») par l'outil « Constats du chiffrier ».

## Contenu

| Fichier | Rôle |
|---------|------|
| `bsi.json` | Le manifeste : c'est ce que BatiFlow lit. Format `batiflow.bsi.dossier`, version 1. |
| `photos/` | Les 0 photo(s) retrouvées sur le poste, référencées par `constats[].photos[].fichier`. |
| `constats.csv` | Les mêmes constats en tableau, pour Excel ou Numbers. |
| `rapport.txt` | Le rapport de lecture : lignes lues, décisions automatiques, avertissements. |

## Chiffres

- 7 constats retenus, 43 860,00 $ au total.
- 8 lignes lues, 1 ligne(s) vide(s) écartée(s).
- 4 avertissement(s) — voir `rapport.txt`.

## Priorités

Le code du rapport fait foi ; il n'est jamais traduit en degré de gravité.

- `U` — Urgent (Urgent)
- `CT` — Court terme (D'ici 1 an)
- `MT` — Moyen terme (D'ici 4 ans)
- `LT` — Long terme (D'ici 9 ans)
- `LT+` — Long terme + (10 ans et plus)
- `EX` — Expertise (Avis d'un expert recommandé)
- `CO` — Entretien (Entretien ou amélioration suggéré)

## Coûts

`coutRetenu` est le montant qui fait foi : celui du chiffrier quand la colonne existe,
sinon quantité × prix unitaire. Quand les deux existent et diffèrent, `ecartDeCout` vaut
`true` et les deux montants restent dans le manifeste (`coutChiffrier`, `coutCalcule`).
